#include <stdio.h>
#include <string.h>
#include <ctype.h>

void removeSpaces(char *str) {
    int i = 0, j = 0;
    while (str[i]) {
        if (str[i] != ' ')
            str[j++] = str[i];
        i++;
    }
    str[j] = '\0';
}

int main() {
    char *CurrentLocations[15] = {
        "delhi", "mumbai", "bengaluru", "chennai", "kolkata",
        "hyderabad", "pune", "ahmedabad", "jaipur", "varanasi",
        "amritsar", "lucknow", "bhopal", "surat", "thiruvananthapuram"
    };

    char *Destinations[15] = {
        "taj mahal", "qutub minar", "gateway of india", "charminar", "hampi",
        "red fort", "golden temple", "meenakshi temple", "india gate", "mysore palace",
        "ajanta caves", "ellora caves", "backwaters of kerala", "dal lake", "statue of unity"
    };

    // Average stay cost per day at each destination (₹)
    int stayCost[15] = {
        2500, 1500, 1800, 1700, 1600,
        2200, 2000, 1900, 1400, 2000,
        2100, 2100, 2300, 1800, 1700
    };

    // Average train cost matrix (₹), rows: current city, cols: destination
    int trainCost[15][15] = {
        // Taj Mahal, Qutub Minar, Gateway of India, Charminar, Hampi, Red Fort, Golden Temple, Meenakshi Temple, India Gate, Mysore Palace, Ajanta Caves, Ellora Caves, Backwaters Kerala, Dal Lake, Statue of Unity
        {600, 40, 1300, 1700, 2200, 60, 650, 2100, 30, 2400, 2500, 2700, 3000, 2200, 1400},  // Delhi
        {1300, 1350, 40, 1200, 1400, 1320, 1700, 900, 1320, 1600, 1800, 1900, 2100, 1600, 1300}, // Mumbai
        {2200, 2150, 1900, 40, 200, 2300, 2600, 300, 2100, 400, 500, 600, 400, 2300, 2500},  // Bengaluru
        {1700, 1650, 1100, 40, 600, 1800, 2100, 200, 1600, 700, 900, 950, 1200, 1600, 1500},  // Chennai
        {2200, 30, 1900, 2100, 2700, 40, 2100, 2300, 40, 2500, 2600, 2700, 2800, 1500, 1800},  // Kolkata
        {650, 600, 700, 40, 500, 200, 40, 900, 30, 1100, 1200, 1300, 1400, 1200, 1100},  // Hyderabad
        {1700, 1650, 1100, 40, 600, 1800, 2100, 200, 1600, 700, 900, 950, 1200, 1600, 1500},  // Pune
        {1400, 1300, 1100, 600, 800, 1200, 1300, 40, 600, 1100, 1200, 1300, 1400, 1100, 1000},  // Ahmedabad
        {800, 700, 1200, 1500, 1800, 900, 1000, 1700, 40, 2000, 2100, 2200, 2300, 1800, 1600},  // Jaipur
        {1100, 1050, 900, 800, 1000, 700, 600, 900, 800, 40, 1000, 1100, 1200, 1100, 1000},  // Varanasi
        {700, 650, 600, 40, 500, 400, 300, 200, 300, 500, 40, 50, 60, 70, 80},  // Amritsar
        {900, 850, 800, 750, 900, 700, 600, 500, 700, 800, 900, 40, 120, 100, 110},  // Lucknow
        {1000, 950, 900, 850, 900, 800, 700, 600, 800, 900, 1000, 1100, 40, 120, 130},  // Bhopal
        {800, 750, 700, 650, 700, 600, 500, 400, 600, 700, 800, 900, 1000, 40, 110},  // Surat
        {1300, 1250, 1200, 1150, 1100, 1000, 900, 800, 900, 1000, 1100, 1200, 1300, 1100, 40}  // Thiruvananthapuram
    };

    // Average car cost matrix (₹)
    int carCost[15][15] = {
        {1100, 80, 2100, 2700, 3200, 120, 1300, 3100, 70, 3400, 3500, 3700, 4000, 3200, 2400},
        {2300, 2350, 80, 2200, 2400, 2320, 2700, 1900, 2320, 2600, 2800, 2900, 3100, 2600, 2300},
        {3200, 3150, 2900, 80, 800, 3300, 3600, 1400, 3100, 1700, 1800, 1900, 1600, 3300, 3500},
        {2700, 2650, 2100, 80, 1200, 2800, 3100, 1100, 2600, 1200, 1400, 1450, 1700, 2600, 2500},
        {3200, 80, 2900, 3100, 3700, 80, 3100, 3300, 80, 3500, 3600, 3700, 3800, 2500, 2800},
        {1300, 1200, 1400, 80, 900, 800, 80, 1900, 70, 2100, 2200, 2300, 2400, 2200, 2100},
        {2700, 2650, 2100, 80, 1200, 2800, 3100, 1100, 2600, 1200, 1400, 1450, 1700, 2600, 2500},
        {2400, 2300, 2100, 1600, 1800, 2200, 2300, 80, 1600, 2100, 2200, 2300, 2400, 2100, 2000},
        {1800, 1700, 2200, 2500, 2800, 1900, 2000, 2700, 80, 3000, 3100, 3200, 3300, 2800, 2600},
        {2100, 2050, 1900, 1800, 2000, 1700, 1600, 1900, 1800, 80, 2000, 2100, 2200, 2100, 2000},
        {1700, 1650, 1600, 80, 1500, 1400, 1300, 1200, 1300, 1500, 80, 90, 100, 110, 120},
        {1900, 1850, 1800, 1750, 1900, 1700, 1600, 1500, 1700, 1800, 1900, 80, 220, 200, 210},
        {2000, 1950, 1900, 1850, 1900, 1800, 1700, 1600, 1800, 1900, 2000, 2100, 80, 220, 230},
        {1800, 1750, 1700, 1650, 1700, 1600, 1500, 1400, 1600, 1700, 1800, 1900, 2000, 80, 210},
        {2300, 2250, 2200, 2150, 2100, 2000, 1900, 1800, 1900, 2000, 2100, 2200, 2300, 2100, 80}
    };

    // Nearby spots for each destination
    char *nearbySpots[15] = {
        "Agra Fort, Mehtab Bagh, Itimad-ud-Daulah's Tomb",         // Taj Mahal
        "Quwwat-ul-Islam Mosque, Alai Minar, Iron Pillar",          // Qutub Minar
        "Elephanta Caves, Colaba Causeway, Marine Drive",           // Gateway of India
        "Mecca Masjid, Chowmahalla Palace, Laad Bazaar",            // Charminar
        "Virupaksha Temple, Vithala Temple Complex, Hemakuta Hill", // Hampi
        "Jama Masjid, Chandni Chowk, Raj Ghat",                     // Red Fort
        "Jallianwala Bagh, Wagah Border",                           // Golden Temple
        "Thirumalai Nayakkar Mahal, Puthu Mandapam",                // Meenakshi Temple
        "Rashtrapati Bhavan, Parliament House",                     // India Gate
        "Brindavan Gardens, Chamundi Hill",                         // Mysore Palace
        "Ellora Caves, Aurangabad Caves",                           // Ajanta Caves
        "Ajanta Caves, Daulatabad Fort",                            // Ellora Caves
        "Kumarakom Bird Sanctuary, Alleppey Beach",                 // Backwaters of Kerala
        "Mughal Gardens, Shankaracharya Temple",                    // Dal Lake
        "Sardar Sarovar Dam, Shoolpaneshwar Wildlife Sanctuary"     // Statue of Unity
    };

    char C[50], D[50];
    int N;

    printf("Enter your Current living city: ");
    scanf(" %[^\n]", C);
    for(int i=0; C[i]; i++) C[i] = tolower(C[i]);
    removeSpaces(C);

    printf("Enter your Destination: ");
    scanf(" %[^\n]", D);
    for(int i=0; D[i]; i++) D[i] = tolower(D[i]);
    removeSpaces(D);

    printf("Enter Number of days to stay: ");
    scanf("%d", &N);

    int cIndex = -1, dIndex = -1;
    for(int i=0; i<15; i++) {
        char tempC[50], tempD[50];
        strcpy(tempC, CurrentLocations[i]);
        strcpy(tempD, Destinations[i]);
        removeSpaces(tempC);
        removeSpaces(tempD);

        if(strcmp(tempC, C) == 0) cIndex = i;
        if(strcmp(tempD, D) == 0) dIndex = i;
    }

    if(cIndex == -1) {
        printf("Sorry, your current city is not in the database.\n");
        return 1;
    }
    if(dIndex == -1) {
        printf("Sorry, your destination is not in the database.\n");
        return 1;
    }

    int totalTrain = trainCost[cIndex][dIndex] + (stayCost[dIndex] * N);
    int totalCar = carCost[cIndex][dIndex] + (stayCost[dIndex] * N);

    printf("\nTrip Details: %s → %s\n", CurrentLocations[cIndex], Destinations[dIndex]);
    printf("By Train: ₹%d\n", trainCost[cIndex][dIndex]);
    printf("By Car: ₹%d\n", carCost[cIndex][dIndex]);
    printf("Stay Cost (per day): ₹%d\n", stayCost[dIndex]);
    printf("Nearby Tourist Spots: %s\n", nearbySpots[dIndex]);
    printf("Total Expenditure (Train): ₹%d + (₹%d × %d days) = ₹%d\n",
           trainCost[cIndex][dIndex], stayCost[dIndex], N, totalTrain);
    printf("Total Expenditure (Car): ₹%d + (₹%d × %d days) = ₹%d\n",
           carCost[cIndex][dIndex], stayCost[dIndex], N, totalCar);

    return 0;
}